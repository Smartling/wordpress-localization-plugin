<?php

if (!function_exists('namespacer_ensure_trailing_slash')) {
	/**
	 * Ensures a string ends with a trailing slash.
	 *
	 * @param string $string The string to process
	 * @return string The string with a trailing slash
	 */
	function namespacer_ensure_trailing_slash(string $string): string {
		return namespacer_remove_trailing_slash($string) . '/';
	}
}

if (!function_exists('namespacer_remove_trailing_slash')) {
	/**
	 * Removes trailing slashes from a string.
	 *
	 * @param string $string The string to process
	 * @return string The string without trailing slashes
	 */
	function namespacer_remove_trailing_slash(string $string): string {
		return rtrim($string, '/\\');
	}
}
