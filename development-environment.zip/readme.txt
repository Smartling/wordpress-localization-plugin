Setup instructions:

Unpack deveopment-environment archieve in folder, e.g.:

	~/projects/smartling-connector

go to 

	~/projects/smartling-connector/code/wp-content/plugins/smartling-connector

and clone there connector repo from github

after all go to

	~/projects/smartling-connector/v-env

and run

	vagrant up

wait until vagrant will setup your environment


notes:

Configured domain name	: http://wp-connector.archer.local
Configured ip           : 192.168.56.112

Wordpress user name     : wp41
Wordpress user pass     : wp41

Mysql user name         : root
Mysql user pass         : root