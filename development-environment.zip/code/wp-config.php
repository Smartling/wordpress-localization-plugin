<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp41');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'fQ~,DAK+E:QE{Dv?tMn5oJ1k24bJHu]73X6?Un8te(:9wsk[l%qd8!vl;@|E{(RX');
define('SECURE_AUTH_KEY',  '-uN.0Rw?ilUE=>p{ n7yxD>!nzc&% LX^90ca#Igqms/j=02NLm>ZT*iiszTje-@');
define('LOGGED_IN_KEY',    '1?!eaw%+]xR=R/OUDJRRxik/{B}jF*HBp94s{=Ql?1:||wZw>i@.y{XXu*Kam}3[');
define('NONCE_KEY',        'x{Z^q0oaLe9cnyGWU!.cL%-?m`+)epaS!~+<ge2$}4t#= sq5CnJ^cqrGpK]f%dO');
define('AUTH_SALT',        '?</,=Hb.9=H1wRN:NwRK=6T+~]q}-cY0|v#AWt+9A+p|`/!}&EEs]yB9dHZEH*&R');
define('SECURE_AUTH_SALT', 'w@6 4`__BT+-nb8:63=Ht|vg)Q1lX;>{jA--aYs,MrRu!GBpk1hG--$JcoYO:KT*');
define('LOGGED_IN_SALT',   '&n qB-j<>g0$G-RP_[-1W~{Y|_2|` -{9xVf|]EDwXjO</ |24~_-: )}1[p/Nqa');
define('NONCE_SALT',       'dQSx7]-0V>YA:]?aMXq/e}~,-_Ax5?=f%j-B.?J+)X_|K0Y&|qM~rz!h_&Nv7#*a');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp41_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

define( 'WP_ALLOW_MULTISITE', TRUE );

define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', false);
define('DOMAIN_CURRENT_SITE', 'wp-connector.archer.local');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

//define( 'SUNRISE', 'on' );

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

