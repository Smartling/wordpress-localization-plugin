#!/usr/bin/sh

mysql -uroot -proot < /var/www/wp-content/plugins/smartling-connector/db_dump.sql