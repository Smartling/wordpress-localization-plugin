<?php

namespace Smartling\Processors;

/**
 * Class TagMapper
 *
 * @package Smartling\Processors
 */
class TagMapper extends TaxonomyMapperAbstract {

}