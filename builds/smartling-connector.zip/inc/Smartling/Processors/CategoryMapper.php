<?php

namespace Smartling\Processors;

/**
 * Class CategoryMapper
 *
 * @package Smartling\Processors
 */
class CategoryMapper extends TaxonomyMapperAbstract {

}