<?php

namespace Smartling\Processors;

/**
 * Class PageMapper
 *
 * @package Smartling\Processors
 */
class PageMapper extends PostMapper {

}