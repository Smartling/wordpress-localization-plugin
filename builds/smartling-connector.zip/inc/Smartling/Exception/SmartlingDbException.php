<?php

namespace Smartling\Exception;

class SmartlingDbException extends SmartlingException {

}