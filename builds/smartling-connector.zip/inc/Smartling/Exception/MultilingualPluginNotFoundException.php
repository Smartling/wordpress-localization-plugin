<?php

namespace Smartling\Exception;


class MultilingualPluginNotFoundException extends SmartlingException {

}