<?php

namespace Smartling\Exception;

class SmartlingDataUpdateException extends SmartlingException {

}