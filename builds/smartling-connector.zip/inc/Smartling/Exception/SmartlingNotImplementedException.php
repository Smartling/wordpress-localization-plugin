<?php

namespace Smartling\Exception;

/**
 * Class SmartlingNotImplementedException
 *
 * @package Smartling\Exception
 */
class SmartlingNotImplementedException extends SmartlingException {

}