<?php

namespace Smartling\Exception;

class SmartlingDirectRunRuntimeException extends SmartlingException {

}