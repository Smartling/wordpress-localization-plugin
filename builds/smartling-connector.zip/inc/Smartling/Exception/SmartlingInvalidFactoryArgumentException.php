<?php

namespace Smartling\Exception;

/**
 * Class SmartlingInvalidFactoryArgumentException
 *
 * @package Smartling\Exception
 */
class SmartlingInvalidFactoryArgumentException extends SmartlingException {

}