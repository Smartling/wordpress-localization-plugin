<?php

namespace Smartling\Exception;

class SmartligFileDownloadException extends SmartlingException {

}