<?php

namespace Smartling\Exception;

class SmartlingSerializeException extends SmartlingException {

}