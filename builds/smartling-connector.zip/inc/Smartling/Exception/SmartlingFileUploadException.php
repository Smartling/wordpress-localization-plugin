<?php

namespace Smartling\Exception;

class SmartlingFileUploadException extends SmartlingNetworkException {

}