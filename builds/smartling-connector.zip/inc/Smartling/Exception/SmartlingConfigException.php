<?php

namespace Smartling\Exception;

class SmartlingConfigException extends SmartlingException {

}