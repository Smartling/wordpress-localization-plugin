<?php

namespace Smartling\Exception;


class SmartlingNetworkException extends SmartlingException {

}