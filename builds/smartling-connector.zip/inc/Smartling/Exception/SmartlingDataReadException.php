<?php

namespace Smartling\Exception;

class SmartlingDataReadException extends SmartlingException {

}