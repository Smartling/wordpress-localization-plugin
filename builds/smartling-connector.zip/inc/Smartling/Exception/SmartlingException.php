<?php

namespace Smartling\Exception;

/**
 * Class SmartlingException
 *
 * @package Smartling\Exception
 *
 * Base class for any Smartling Exception
 */
abstract class SmartlingException extends \Exception {

}
