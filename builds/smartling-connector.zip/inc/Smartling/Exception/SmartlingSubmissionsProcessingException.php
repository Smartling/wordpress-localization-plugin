<?php

namespace Smartling\Exception;

class SmartlingSubmissionsProcessingException extends SmartlingException {

}