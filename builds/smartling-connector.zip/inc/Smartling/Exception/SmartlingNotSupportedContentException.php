<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 13.02.2015
 * Time: 12:26
 */

namespace Smartling\Exception;


class SmartlingNotSupportedContentException extends SmartlingException {

}