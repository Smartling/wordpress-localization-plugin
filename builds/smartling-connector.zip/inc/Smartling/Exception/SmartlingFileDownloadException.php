<?php

namespace Smartling\Exception;

/**
 * Class SmartlingFileDownloadException
 *
 * @package Smartling\Exception
 */
class SmartlingFileDownloadException extends SmartlingNetworkException {

}