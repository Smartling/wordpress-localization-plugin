<?php


namespace Smartling\Exception;

/**
 * Class EntityNotFoundException
 *
 * @package Smartling\Exception
 */
class EntityNotFoundException extends SmartlingException {

}