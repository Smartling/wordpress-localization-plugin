<?php
/*
 * This file is part of the Comparator package.
 *
 * (c) Sebastian Bergmann <sebastian@phpunit.de>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace SebastianBergmann\Comparator;

/**
 * Compares numerical values for equality.
 *
 * @package    Comparator
 * @author     Bernhard Schussek <bschussek@2bepublished.at>
 * @author     Alexander <iam.asm89@gmail.com>
 * @copyright  Sebastian Bergmann <sebastian@phpunit.de>
 * @license    http://www.opensource.org/licenses/BSD-3-Clause  The BSD 3-Clause License
 * @link       http://www.github.com/sebastianbergmann/comparator
 */
class NumericComparator extends ScalarComparator {
	/**
	 * Returns whether the comparator can compare two values.
	 *
	 * @param  mixed $expected The first value to compare
	 * @param  mixed $actual   The second value to compare
	 *
	 * @return boolean
	 */
	public function accepts ( $expected, $actual ) {
		// all numerical values, but not if one of them is a double
		// or both of them are strings
		return is_numeric( $expected ) && is_numeric( $actual ) &&
		       ! ( is_double( $expected ) || is_double( $actual ) ) &&
		       ! ( is_string( $expected ) && is_string( $actual ) );
	}

	/**
	 * Asserts that two values are equal.
	 *
	 * @param  mixed $expected     The first value to compare
	 * @param  mixed $actual       The second value to compare
	 * @param  float $delta        The allowed numerical distance between two values to
	 *                             consider them equal
	 * @param  bool  $canonicalize If set to TRUE, arrays are sorted before
	 *                             comparison
	 * @param  bool  $ignoreCase   If set to TRUE, upper- and lowercasing is
	 *                             ignored when comparing string values
	 *
	 * @throws ComparisonFailure Thrown when the comparison
	 *                           fails. Contains information about the
	 *                           specific errors that lead to the failure.
	 */
	public function assertEquals ( $expected, $actual, $delta = 0.0, $canonicalize = false, $ignoreCase = false ) {
		if ( is_infinite( $actual ) && is_infinite( $expected ) ) {
			return;
		}

		if ( ( is_infinite( $actual ) xor is_infinite( $expected ) ) ||
		     ( is_nan( $actual ) or is_nan( $expected ) ) ||
		     abs( $actual - $expected ) > $delta
		) {
			throw new ComparisonFailure(
				$expected,
				$actual,
				'',
				'',
				false,
				sprintf(
					'Failed asserting that %s matches expected %s.',
					$this->exporter->export( $actual ),
					$this->exporter->export( $expected )
				)
			);
		}
	}
}
